const mongoose = require("mongoose");

const blogSchema = new mongoose.Schema({
  userName: String,
  category: String,
  subcategory: String,
  description: String,
  image_path: String,
  datetime: String,
});

module.exports = mongoose.model("Blog", blogSchema);
