const jwt = require("jsonwebtoken");
const sec_key = process.env.SECRET_KEY;

const authMiddleware = (req, res, next) => {
  try {
    let token = req.headers.authorization;
    if (!token) {
      return res.status(401).json({ message: "Unauthorized user" });
    }

    token = token.split(" ")[1];
    const decoded = jwt.verify(token, sec_key);
    req.userId = decoded.id;
    next();
  } catch (e) {
    res.status(401).json({ message: "Invalid or expired token" });
  }
};

module.exports = authMiddleware;
