const express = require("express");
const cors = require("cors");
require("dotenv").config();
require("./db");
const path = require("path");

const app = express();
const port = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static image files
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// Routers
const blogRoutes = require("./routers/blogRouter");
const authRoutes = require("./routers/authRouter");

app.use("/blog", blogRoutes);
app.use("/user", authRoutes);

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
