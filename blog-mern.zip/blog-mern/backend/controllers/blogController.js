const Blog = require("../models/blogModel");

const store = async (req, res) => {
  try {
    const blog = new Blog({
      userName: req.body.userName,
      category: req.body.category,
      subcategory: req.body.subcategory,
      description: req.body.description,
      image_path: req.file ? req.file.filename : null,
      datetime: req.body.datetime,
    });
    const result = await blog.save();
    res.status(200).json({ status: "ok", result, message: "Blog saved successfully" });
  } catch (e) {
    res.status(500).json({ status: "error", message: e.message });
  }
};

const fetchall = async (req, res) => {
  try {
    const result = await Blog.find();
    res.status(200).json({ status: "ok", data: result });
  } catch (e) {
    res.status(500).json({ status: "error", message: e.message });
  }
};

const destroy = async (req, res) => {
  try {
    const result = await Blog.findByIdAndDelete(req.params.id);
    res.status(200).json({ status: "ok", result });
  } catch (e) {
    res.status(500).json({ status: "error", message: e.message });
  }
};

const update = async (req, res) => {
  try {
    const data = {
      userName: req.body.userName,
      category: req.body.category,
      subcategory: req.body.subcategory,
      description: req.body.description,
      image_path: req.file ? req.file.filename : req.body.image_path,
      datetime: req.body.datetime,
    };
    const result = await Blog.findByIdAndUpdate(req.params.id, data, { new: true });
    res.status(200).json({ status: "ok", result });
  } catch (e) {
    res.status(500).json({ status: "error", message: e.message });
  }
};

module.exports = { store, fetchall, destroy, update };
