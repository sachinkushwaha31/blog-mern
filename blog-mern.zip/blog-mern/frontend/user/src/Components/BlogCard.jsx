import React from "react";

const BlogCard = ({ post, onEdit, onDelete }) => {
  return (
    <div className="col-md-6 col-lg-4 mb-4">
      <div className="card h-100 shadow">
        <img
          src={`http://localhost:5000/uploads/${post.image_path}`}
          alt={post.category}
          className="card-img-top img-fluid"
          style={{ height: "200px", objectFit: "cover", width: "100%" }}
        />
        <div className="card-body">
          <h5 className="card-title">{post.category}</h5>
          <h6 className="text-muted">{post.subcategory}</h6>
          <p className="card-text text-truncate">{post.description}</p>
          <small className="text-muted">
            By {post.userName} on {new Date(post.datetime).toLocaleString()}
          </small>
        </div>

        {/* Buttons aligned to the right */}
        <div className="card-footer">
          <div className="d-flex justify-content-end gap-2">
            <button className="btn btn-sm btn-primary" onClick={onEdit}>
              Edit
            </button>
            <button className="btn btn-sm btn-danger" onClick={onDelete}>
              Delete
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BlogCard;
