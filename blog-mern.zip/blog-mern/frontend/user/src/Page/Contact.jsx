import React, { useState } from "react";
import axios from "axios";

function Contact() {
  const [contactForm, setContactForm] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: "",
  });

  const handlecontact = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost/blog/inquiry_add.php", contactForm);
      e.preventDefault();
      alert("Inquiry submitted successfully");
        setContactForm({
          name: "",
          email: "",
          phone: "",
          subject: "",
          message: "",
        });
    } catch (e) {
      console.log(e.message);
      alert("Something went wrong!");
    }
  };

  

  return (
    <>
      {/* contact section start */}
      <div className="contact_section layout_padding">
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <div
                id="carouselExampleIndicators"
                className="carousel slide"
                data-ride="carousel"
              >
                <div className="carousel-inner">
                  <div className="carousel-item active">
                    <div className="contact_img" />
                  </div>
                  <div className="carousel-item">
                    <div className="contact_img" />
                  </div>
                  <div className="carousel-item">
                    <div className="contact_img" />
                  </div>
                  <div className="carousel-item">
                    <div className="contact_img" />
                  </div>
                </div>
              </div>
            </div>

            <div className="col-md-6">
              <div className="mail_section">
                <h1 className="contact_taital">Contact us</h1>
                <input
                  type="text"
                  className="email_text"
                  placeholder="Name"
                  name="Name"
                  value={contactForm.name}
                  onChange={(e) =>
                    setContactForm({ ...contactForm, name: e.target.value })
                  }
                />
                <input
                  type="email"
                  className="email_text"
                  placeholder="Email"
                  name="Email"
                  value={contactForm.email}
                  onChange={(e) =>
                    setContactForm({ ...contactForm, email: e.target.value })
                  }
                />
                <input
                  type="tel"
                  className="email_text"
                  placeholder="Phone"
                  name="Phone"
                  value={contactForm.phone}
                  onChange={(e) =>
                    setContactForm({ ...contactForm, phone: e.target.value })
                  }
                />
                <input
                  type="text"
                  className="email_text"
                  placeholder="Subject"
                  name="Subject"
                  value={contactForm.subject}
                  onChange={(e) =>
                    setContactForm({ ...contactForm, subject: e.target.value })
                  }
                />
                <textarea
                  className="massage_text"
                  placeholder="Message"
                  rows={5}
                  id="comment"
                  name="Message"
                  value={contactForm.message}
                  onChange={(e) =>
                    setContactForm({ ...contactForm, message: e.target.value })
                  }
                />
                <div className="send_bt">
                  {/* Changed from <a href="#"> to button to avoid page reload */}
                  <a href="#" onClick={handlecontact}>
                    send
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* contact section end */}
    </>
  );
}

export default Contact;
