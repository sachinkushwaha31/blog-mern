import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import BlogCard from "../Components/BlogCard";

function Home() {
  const [posts, setPosts] = useState([]);

  const fetchPosts = async () => {
    try {
      const response = await axios.get("http://localhost:5000/blog");
      if (response.data.status === "ok") {
        setPosts(response.data.data.slice(0, 3));
      } else {
        alert("Failed to fetch posts.");
      }
    } catch (error) {
      console.error("Error fetching posts:", error);
    }
  };

  useEffect(() => {
    fetchPosts();
  }, []);

  return (
    <>
      <div className="container-fluid">
        <div className="banner_section layout_padding">
          <h1 className="banner_taital">
            welcome <br />
            our blog
          </h1>
          <div id="my_slider" className="carousel slide" data-ride="carousel">
            <div className="carousel-inner">
              <div className="carousel-item active">
                <div className="image_main">
                  <div className="container">
                    <img src="assets/images/img-1.png" className="image_1" />
                    <div className="contact_bt">
                      <a href="contact.html">About Us</a>
                    </div>
                  </div>
                </div>
              </div>
              <div className="carousel-item">
                <div className="image_main">
                  <div className="container">
                    <img src="assets/images/img-2.png" className="image_1" />
                    <div className="contact_bt">
                      <a href="contact.html">About Us</a>
                    </div>
                  </div>
                </div>
              </div>
              <div className="carousel-item">
                <div className="image_main">
                  <div className="container">
                    <img src="assets/images/img-2.png" className="image_1" />
                    <div className="contact_bt">
                      <a href="contact.html">About Us</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/* <a
              className="carousel-control-prev"
              href="#my_slider"
              role="button"
              data-slide="prev"
            >
              <i className="fa fa-angle-left" />
            </a> */}
            {/* <a
              className="carousel-control-next"
              href="#my_slider"
              role="button"
              data-slide="next"
            >
              <i className="fa fa-angle-right" />
            </a> */}
          </div>
        </div>
      </div>
      <div className="container-fluid">
        <div className="about_section layout_padding">
          <div className="container">
            <div className="row">
              <div className="row">
                {/* <div className="col-lg-12">
                  <h1 className="about-section">About</h1>
                </div> */}
              </div>
              <div className="col-lg-8 col-sm-12">
                <div className="about_img">
                  <img src="assets/images/about-img.png" />
                </div>
                <div className="like_icon">
                  <img src="assets/images/like-icon.png" />
                </div>
                {/* <p className="post_text">Post By : 09/06/2019</p>
                <h2 className="most_text">
                  Most Awesome Blue Lake With Snow <br />
                  Mountain
                </h2>
                <p className="lorem_text">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  Ut enim ad minim veniam, quis
                </p> */}
                {/* <div className="social_icon_main">
                  <div className="social_icon">
                    <ul>
                      <li>
                        <a href="#">
                          <img src="assets/images/fb-icon.png" />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <img src="assets/images/twitter-icon.png" />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <img src="assets/images/instagram-icon.png" />
                        </a>
                      </li>
                    </ul>
                  </div>
                  <div className="read_bt">
                    <a href="#">Read More</a>
                  </div>
                </div> */}
              </div>
              <div className="col-lg-4 col-sm-12">
                <div className="image_5">
                  <img src="assets/images/img-5.png" />
                </div>
                <h1 className="about_taital">About Us</h1>
                <p className="about_text">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  Ut enim ad minim veniam, quis
                </p>
                <div className="read_bt_1">
                  <a href="#">Read More</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* <div
        className="container-fluid text-center"
        style={{ marginTop: "blue" }}
      >
        <h1 className="display-4 fw-bold">
          Welcome to <span className="text-warning">DailyNews</span>
        </h1>
        <p>Stay informed with the latest articles and insights</p>
      </div> */}

      {/* Latest Blog Posts Section */}
      <div className="container mt-5">
        <h2 className="text-center mb-5">Latest Blog Posts</h2>
        <div className="row">
          {posts.map((post) => (
            <BlogCard key={post._id} post={post} />
          ))}
        </div>
        <div className="row">
          <div className="d-flex justify-content-center align-items-center px-3">
            <Link to="/all-blog" className="btn btn-outline-primary">
              View All Posts
            </Link>
          </div>
        </div>
      </div>
    </>
  );
}

export default Home;
