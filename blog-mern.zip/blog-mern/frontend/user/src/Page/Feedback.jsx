import axios from "axios";
import React, { useState, useEffect } from "react";

function Feedback() {
  const [feedbackForm, setFeedbackForm] = useState({
    name: "",
    email: "",
    phone: "",
    rating: "",
    message: ""
  });

  const handlefeedbackform = async (e) => {
    e.preventDefault();

    // Basic front validation
    if (
      !feedbackForm.name ||
      !feedbackForm.email ||
      !feedbackForm.phone ||
      !feedbackForm.rating ||
      !feedbackForm.message
    ) {
      alert("Please fill all fields");
      return;
    }
    if (feedbackForm.rating < 1 || feedbackForm.rating > 5) {
      alert("Rating must be between 1 and 5");
      return;
    }

    try {
      const response = await axios.post(
        "http://localhost/blog/feedback_add.php",
        feedbackForm,
        {
          headers: {
            "Content-Type": "application/json"
          }
        }
      );

      if (response.data.status === "success") {
        alert("Feedback submitted successfully!");
        setFeedbackForm({
          name: "",
          email: "",
          phone: "",
          rating: "",
          message: ""
        });
      } else {
        alert("Error: " + response.data.message);
      }
    } catch (error) {
      console.error("Submission Error:", error.message);
      alert("Failed to submit feedback. Please try again.");
    }
  };

  return (
    <>
      <div className="contact_section layout_padding">
        <div className="container">
          <div className="row">
            {/* Left Side */}
            <div className="col-md-6">
              <div className="carousel slide" data-ride="carousel">
                <div className="carousel-inner">
                  <div className="carousel-item active">
                    <div className="feedback_img" />
                  </div>
                </div>
              </div>
            </div>

            {/* Right Side - Feedback Form */}
            <div className="col-md-6">
              <div className="mail_section">
                <h1 className="contact_taital">Feedback</h1>
                <form onSubmit={handlefeedbackform}>
                  <input
                    type="text"
                    className="email_text"
                    placeholder="Name"
                    value={feedbackForm.name}
                    onChange={(e) => setFeedbackForm({ ...feedbackForm, name: e.target.value })}
                  />
                  <input
                    type="email"
                    className="email_text"
                    placeholder="Email"
                    value={feedbackForm.email}
                    onChange={(e) => setFeedbackForm({ ...feedbackForm, email: e.target.value })}
                  />
                  <input
                    type="tel"
                    className="email_text"
                    placeholder="Phone"
                    value={feedbackForm.phone}
                    onChange={(e) => setFeedbackForm({ ...feedbackForm, phone: e.target.value })}
                  />
                  <input
                    type="number"
                    min="1"
                    max="5"
                    className="email_text"
                    placeholder="Rating (1-5)"
                    value={feedbackForm.rating}
                    onChange={(e) => setFeedbackForm({ ...feedbackForm, rating: e.target.value })}
                  />
                  <textarea
                    className="massage_text"
                    placeholder="Message"
                    rows={5}
                    value={feedbackForm.message}
                    onChange={(e) => setFeedbackForm({ ...feedbackForm, message: e.target.value })}
                  />
                  <div className="send_bt">
                    <button className="btn btn btn-primary" type="submit">Send</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Feedback;
