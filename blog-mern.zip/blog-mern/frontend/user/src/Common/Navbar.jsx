import axios from 'axios';
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";

function Navbar() {
  const [show, setShow] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleShow = () => setShow(!show);
  const toggleDropdown = () => setDropdownOpen(!dropdownOpen);

  // const handleLogout = async () => {
  //   try {
  //     await axios.get("http://localhost/newsblog/logout.php", isLoggedIn);
  //     setIsLoggedIn(false);
  //     alert("Logged out");
  //   } catch (error) {
  //     console.log("Logged out");
  //   }
  // };

  const handleLogout = async () => {
  try {
    await axios.get("http://localhost/newsblog/logout.php", {
      withCredentials: true,
    });
    setIsLoggedIn(false);
    alert("Logged out");
  } catch (error) {
    console.log("Logout failed", error);
  }
};


  // useEffect(() => {
  //   setIsLoggedIn(true);
  // }, []);

  useEffect(() => {
    const checkLoginStatus = async () => {
      try {
        const response = await axios.get("http://localhost/newsblog/logout.php", {
          withCredentials: true,
        });
        setIsLoggedIn(response.data.loggedIn);
      } catch (error) {
        console.error("Auth check failed", error);
        setIsLoggedIn(false);
      }
    };

    checkLoginStatus();
  }, []);


  return (
    <div className="header_section">
      <div className="container-fluid header_main">
        <nav className="navbar navbar-expand-lg navbar-light">
          <Link className="navbar-brand logo" to={"/home"}>
            {/* <img src="/assets/images/logo.png" alt="Logo" /> */}
          </Link>

          <button
            onClick={handleShow}
            className="navbar-toggler"
            type="button"
            aria-expanded={show}
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon" />
          </button>

          <div className={`collapse navbar-collapse ${show ? "show" : ""}`}>

            <ul className="navbar-nav mr-auto">
              <li className="nav-item">
                <Link className="nav-link" to={"/home"}>Home</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to={"/about"}>About</Link>
              </li>

              {/* Manual Blog Dropdown */}
              <li
                className={`nav-item dropdown ${dropdownOpen ? "show" : ""}`}
                onMouseEnter={toggleDropdown}
                onMouseLeave={toggleDropdown}
              >
                <span
                  className="nav-link dropdown-toggle"
                  role="button"
                  aria-haspopup="true"
                  aria-expanded={dropdownOpen}
                >
                  Blog
                </span>
                <div
                  className={`dropdown-menu ${dropdownOpen ? "show" : ""}`}
                >
                  <Link className="dropdown-item" to={"/add-blog"}>Add Blog</Link>
                  <Link className="dropdown-item" to={"/all-blog"}>All Blogs</Link>
                </div>
              </li>

              <li className="nav-item">
                <Link className="nav-link" to={"/feedback"}>Feedback</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to={"/contact"}>Contact Us</Link>
              </li>
              {!isLoggedIn ? (
                <li className="nav-item">
                  <Link className="nav-link" to={"/login"}>Login</Link>
                </li>
              ) : (
                <li className="nav-item">
                  <button className="nav-link btn btn-link" onClick={handleLogout}>
                    Logout
                  </button>
                </li>
              )}
              <li className="nav-item">
                <Link className="nav-link" to={"/search"}>
                  <img src="/assets/images/serach-icon.png" alt="Search" />
                </Link>
              </li>
            </ul>
          </div>
        </nav>
      </div>
    </div>
  );
}

export default Navbar;
