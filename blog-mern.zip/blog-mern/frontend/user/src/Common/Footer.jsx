import React from "react";

function Footer() {
  return (
    <>
      <div className="copyright_section">
        <div className="container">
          <p className="copyright_text">
            Copyright 2020 All Right Reserved By.
            <a href="https://html.design"> Free html Templates</a>
          </p>
        </div>
      </div>
    </>
  );
}

export default Footer;
