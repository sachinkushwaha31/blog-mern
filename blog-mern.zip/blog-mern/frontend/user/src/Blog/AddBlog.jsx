import axios from "axios";
import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";

const AddBlog = () => {
  const [addBlog, setAddBlog] = useState({
    _id: "",
    userName: "",
    category: "",
    subcategory: "",
    description: "",
    image_path: null,
    datetime: "",
  });

  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    if (location.state) {
      setAddBlog(location.state);
    }
  }, [location.state]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setAddBlog({ ...addBlog, [name]: value });
  };

  const handleImageChange = (e) => {
    setAddBlog({ ...addBlog, image_path: e.target.files[0] });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append("userName", addBlog.userName);
    formData.append("category", addBlog.category);
    formData.append("subcategory", addBlog.subcategory);
    formData.append("description", addBlog.description);
    formData.append("datetime", addBlog.datetime);

    if (addBlog.image_path instanceof File) {
      formData.append("image", addBlog.image_path);
    } else {
      formData.append("image_path", addBlog.image_path);
    }

    try {
      if (addBlog._id) {
        // 🟡 Update (PUT)
        const res = await axios.put(`http://localhost:5000/blog/${addBlog._id}`, formData);
        if (res.data.result) {
          alert("Blog updated successfully");
          navigate("/all-blog");
        } else {
          alert("Failed to update blog");
        }
      } else {
        // 🟢 Add new (POST)
        const res = await axios.post("http://localhost:5000/blog", formData);
        if (res.data.result || res.data.status === "ok") {
          alert("Blog added successfully");
          navigate("/all-blog");
        } else {
          alert("Failed to add blog");
        }
      }
    } catch (err) {
      console.error(err);
      alert("Error saving blog");
    }
  };

  const handleCancel = () => {
    navigate("/all-blog");
  };

  const handleDelete = async () => {
    const confirmDelete = window.confirm("Are you sure you want to delete this blog?");
    if (!confirmDelete) return;

    try {
      const res = await axios.delete(`http://localhost:5000/blog/${addBlog._id}`);
      if (res.data.result) {
        alert("Blog deleted successfully");
        navigate("/all-blog");
      } else {
        alert("Failed to delete blog");
      }
    } catch (err) {
      console.error(err);
      alert("Error deleting blog");
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="mb-4 text-center">{addBlog._id ? "Edit Blog Post" : "Add New Blog Post"}</h2>

      <form onSubmit={handleSubmit} encType="multipart/form-data">
        <div className="row mb-3">
          <div className="col-md-6">
            <label className="form-label">Category</label>
            <input
              type="text"
              name="category"
              value={addBlog.category}
              onChange={handleChange}
              className="form-control"
              required
            />
          </div>
          <div className="col-md-6">
            <label className="form-label">Subcategory</label>
            <input
              type="text"
              name="subcategory"
              value={addBlog.subcategory}
              onChange={handleChange}
              className="form-control"
            />
          </div>
        </div>

        <div className="mb-3">
          <label className="form-label">Description</label>
          <textarea
            name="description"
            value={addBlog.description}
            onChange={handleChange}
            className="form-control"
            rows="4"
            required
          ></textarea>
        </div>

        <div className="row mb-3">
          <div className="col-md-4">
            <label className="form-label">User Name</label>
            <input
              type="text"
              name="userName"
              value={addBlog.userName}
              onChange={handleChange}
              className="form-control"
              required
            />
          </div>

          <div className="col-md-4">
            <label className="form-label">Image</label>
            <input
              type="file"
              name="image"
              accept="image/*"
              onChange={handleImageChange}
              className="form-control"
            />
          </div>

          <div className="col-md-4">
            <label className="form-label">Date & Time</label>
            <input
              type="datetime-local"
              name="datetime"
              value={addBlog.datetime}
              onChange={handleChange}
              className="form-control"
              required
            />
          </div>
        </div>

        <div className="d-flex gap-2">
          <button type="submit" className="btn btn-success w-100">
            {addBlog._id ? "Update" : "Add"}
          </button>

          {addBlog._id && (
            <button type="button" className="btn btn-danger w-100" onClick={handleDelete}>
              Delete
            </button>
          )}

          <button type="button" className="btn btn-secondary w-100" onClick={handleCancel}>
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
};

export default AddBlog;
