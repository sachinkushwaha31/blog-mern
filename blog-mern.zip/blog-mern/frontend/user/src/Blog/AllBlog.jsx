import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import BlogCard from "../Components/BlogCard";

const AllBlog = () => {
  const [posts, setPosts] = useState([]);
  const navigate = useNavigate();

  const fetchPosts = async () => {
    try {
      const response = await axios.get("http://localhost:5000/blog");
      if (response.data.status === "ok") {
        setPosts(response.data.data);
      } else {
        alert("Failed to load posts.");
      }
    } catch (error) {
      console.error("Error fetching posts:", error);
      alert("Something went wrong.");
    }
  };

  const handleEdit = (post) => {
    navigate("/add-blog", { state: post });
  };

  const handleDelete = async (id) => {
    const confirm = window.confirm("Are you sure you want to delete this blog?");
    if (!confirm) return;

    try {
      const res = await axios.delete(`http://localhost:5000/blog/${id}`);
      if (res.data.result) {
        alert("Blog deleted successfully");
        fetchPosts(); // Refresh the blog list
      } else {
        alert("Failed to delete blog");
      }
    } catch (err) {
      console.error("Delete error:", err);
      alert("Error deleting blog");
    }
  };

  useEffect(() => {
    fetchPosts();
  }, []);

  return (
    <div className="container py-5">
      <h2 className="text-center mb-4">All Blog Posts</h2>
      <div className="row">
        {posts.map((post) => (
          <BlogCard
            key={post._id}
            post={post}
            onEdit={() => handleEdit(post)}
            onDelete={() => handleDelete(post._id)}
          />
        ))}
      </div>
    </div>
  );
};

export default AllBlog;
