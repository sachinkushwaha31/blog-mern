import axios from "axios";
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

function Register() {
  const [register, setRegister] = useState({
    name: "",
    email: "",
    contact: "",
    password: "",
    confirmPassword: "",
  });

  const [isPasswordMismatch, setIsPasswordMismatch] = useState(false);
  const navigate = useNavigate();

  const handleSubmitRegister = async (e) => {
    e.preventDefault();

    if (register.password !== register.confirmPassword) {
      setIsPasswordMismatch(true);
      alert("Passwords do not match");
      return;
    }

    try {
      const res = await axios.post("http://localhost:5000/user/signup", {
        name: register.name,
        email: register.email,
        contact: register.contact,
        password: register.password,
      });

      const data = res.data;
      if (data.message) {
        alert("Registered Successfully");
        setRegister({
          name: "",
          email: "",
          contact: "",
          password: "",
          confirmPassword: "",
        });
        setIsPasswordMismatch(false);
        navigate("/login");
      }
    } catch (error) {
      alert("Registration failed. " + (error.response?.data?.message || ""));
    }
  };

  return (
    <div className="register-container">
      <div className="register-box">
        <h2>Register</h2>
        <form onSubmit={handleSubmitRegister}>
          <input
            type="text"
            name="name"
            placeholder="Full Name"
            value={register.name}
            onChange={(e) => setRegister({ ...register, name: e.target.value })}
            required
          />
          <input
            type="email"
            name="email"
            placeholder="Email"
            value={register.email}
            onChange={(e) => setRegister({ ...register, email: e.target.value })}
            required
          />
          <input
            type="text"
            name="contact"
            placeholder="Contact Number"
            value={register.contact}
            onChange={(e) => setRegister({ ...register, contact: e.target.value })}
            required
          />
          <input
            type="password"
            name="password"
            placeholder="Password"
            value={register.password}
            onChange={(e) => setRegister({ ...register, password: e.target.value })}
            required
          />
          <input
            type="password"
            name="confirmPassword"
            placeholder="Confirm Password"
            value={register.confirmPassword}
            onChange={(e) =>
              setRegister({ ...register, confirmPassword: e.target.value })
            }
            required
          />

          <button type="submit">Register</button>

          <h5 className="sing mt-2">
            <Link to="/login">I have an account. Log in</Link>
          </h5>
        </form>
      </div>
    </div>
  );
}

export default Register;
