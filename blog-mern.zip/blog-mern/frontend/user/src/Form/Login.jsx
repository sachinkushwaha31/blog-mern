import axios from 'axios';
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

function Login() {
  const [login, setLogin] = useState({ email: "", password: "" });
  const navigate = useNavigate();

  const handleSubmitLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post("http://localhost:5000/user/signin", login);
      alert("Login Successful");
      setLogin({ email: "", password: "" });

      // You can store token if needed:
      // localStorage.setItem("token", response.data.token);

      navigate("/home"); // Redirect to home page
    } catch (error) {
      alert("Login failed. " + (error.response?.data?.message || ""));
    }
  };

  return (
    <div className='login-container w-100'>
      <div className='login-box'>
        <h2>Log in</h2>
        <div className='detail mx-auto'>
          <form onSubmit={handleSubmitLogin}>
            <label>Email</label>
            <input
              type='email'
              placeholder='Enter your email'
              className='mx-auto w-100'
              value={login.email}
              onChange={(e) => setLogin({ ...login, email: e.target.value })}
              required
            />

            <label>Password</label>
            <input
              type='password'
              placeholder='Enter your password'
              className='mx-auto w-100'
              value={login.password}
              onChange={(e) => setLogin({ ...login, password: e.target.value })}
              required
            />

            <button type='submit' className='mx-auto w-100 mb-2 text-white btn btn-primary'>
              Log in
            </button>

            <h5 className='sing mt-2'>
              I don't have an account? <br />
              <Link to='/register'>Sign Up</Link>
            </h5>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Login;
