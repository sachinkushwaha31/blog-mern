import "./App.css";
import { Routes, Route } from "react-router-dom";
import Navbar from "./Common/Navbar";
import Footer from "./Common/Footer";
import Feedback from "./Page/Feedback";
import About from "./Page/About";
import Contact from "./Page/Contact";
import Home from "./Page/Home";
import Login from "./Form/Login";
import Register from "./Form/Register";
import AddBlog from "./Blog/AddBlog";
import AllBlog from "./Blog/AllBlog";

function App() {
  return (
    <div className="App">
      <div className="nav">
        <Navbar />
      </div>
      <div className="maindiv">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/home" element={<Home />} />
          <Route path="/navbar" element={<Navbar />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/feedback" element={<Feedback />} />
          <Route path="/add-blog" element={<AddBlog />} />
          <Route path="/all-blog" element={<AllBlog />} />
        </Routes>
      </div>
      <Footer />
    </div>
  );
}

export default App;
