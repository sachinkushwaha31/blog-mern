import React from "react";
import { Routes, Route, useLocation } from "react-router-dom";

import Header from "./components/Common/Header";
import Footer from "./components/Common/Footer";

import AddSubCategory from "./components/Page/AddSubCategory";
import AllCategory from "./components/Page/AllCategory";
import AllUser from "./components/Page/AllUser";
import AllPost from "./components/Page/AllPost";
import AllInquiry from "./components/Page/AllInquiry";
import AllFeedback from "./components/Page/AllFeedback";
import Login from "./components/Form/Login";
import Dashboard from "./components/Page/Dashboard";
import AllSubCategory from "./components/Page/AllSubCategory";
import UserDetails from "./components/Page/UserDetails";
import AddCategory from "./components/Page/AddCategory";

function App() {
  const location = useLocation();
  const isLoginPage = location.pathname === "/login";

  return (
    <>
      {!isLoginPage && <Header />}

      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/" element={<Dashboard />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/addcategory" element={<AddCategory />} />
        <Route path="/addcategory/:id" element={<AddCategory />} />
        <Route path="/addsubcategory" element={<AddSubCategory />} />
        <Route path="/allcategory" element={<AllCategory />} />
        <Route path="/allsubCategory" element={<AllSubCategory />} />
        <Route path="/posts" element={<AllPost />} />
        <Route path="/inquiry" element={<AllInquiry />} />
        <Route path="/feedback" element={<AllFeedback />} />
        <Route path="/users" element={<UserDetails />} />
        <Route path="/user/:id" element={<UserDetails />} />
      </Routes>

      {!isLoginPage && <Footer />}
    </>
  );
}

export default App;
