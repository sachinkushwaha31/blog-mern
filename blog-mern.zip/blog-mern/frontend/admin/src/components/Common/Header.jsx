import React, { useState } from "react";
import Sidebar from "./Sidebar";
import { Link } from "react-router-dom";

function Header() {
  const [sidebarVisible, setSidebarVisible] = useState(true);
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const toggleSidebar = () => {
    setSidebarVisible(sidebarVisible ? false : true);
  };

  const toggleDropdown = () => {
    setDropdownOpen(dropdownOpen ? false : true);
  };

  return (
    <>
      {/* Header start */}
      <header className="header fixed-top clearfix">
        {/* Logo start */}
        <div className="brand">
          <Link to="/" className="logo">
            ADMIN
          </Link>
          <div className="sidebar-toggle-box" onClick={toggleSidebar}>
            <div className="fa fa-bars" />
          </div>
        </div>
        <div className="top-nav clearfix">
          {/* Search & user info start */}
          <ul className="nav pull-right top-menu">
            <li>
              <input
                type="text"
                className="form-control search"
                placeholder=" Search"
              />
            </li>
            {/* user login dropdown */}
            <li className="dropdown">
              <Link
                onClick={toggleDropdown}
                className="dropdown-toggle"
                href="#"
              >
                <img alt="" src="images/2.png" />
                <span className="username">Profile</span>
                <b className="caret" />
              </Link>
              {dropdownOpen && (
                <ul className="dropdown-menu extended logout show">
                  <li>
                    <Link href="#">
                      <i className="fa-solid fa-users"></i>
                      Profile
                    </Link>
                  </li>
                  <li>
                    <Link href="#">
                      <i className="fa fa-cog" /> Registration
                    </Link>
                  </li>
                  <li>
                    <Link href="login.jsx">
                      <i className="fa fa-key" /> Login
                    </Link>
                  </li>
                </ul>
              )}
            </li>
          </ul>
          {/* Search & user info end */}
        </div>
      </header>
      {/* Header end */}

      {/* Sidebar panel */}
      <div className={`sidebar ${sidebarVisible ? "visible" : "hidden"}`}>
        <Sidebar />
      </div>
    </>
  );
}

export default Header;
