import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

function Sidebar() {
  const [isCategoryOpen, setIsCategoryOpen] = useState(false);
  const [isSubCategoryOpen, setIsSubCategoryOpen] = useState(false);
  const navigate = useNavigate()

  return (
    <>
      {/*sidebar start*/}
      <aside>
        <div id="sidebar" className="nav-collapse">
          {/* sidebar menu start*/}
          <div className="leftside-navigation">
            <ul className="sidebar-menu" id="nav-accordion">
              <li>
                <Link className="active" to="/dashboard">
                  <i className="fa fa-dashboard" />
                  <span>Dashboard</span>
                </Link>
              </li>

              {/* Category Dropdown */}
              <li className="sub-menu">
                <a
                  href="/"
                  onClick={(e) => {
                    e.preventDefault();
                    setIsCategoryOpen(isCategoryOpen ? false : true);
                  }}
                >
                  <i className="fa fa-list-alt" />
                  <span>Category</span>
                  <span className="dcjq-icon" />
                </a>
                {isCategoryOpen && (
                  <ul className="sub">
                    <li>
                      <Link to="/AddCategory">
                         <i className="fa fa-list-alt" />
                          Add Category
                      </Link>
                    </li>
                    <li>
                      <Link to="/AllCategory">
                        <i className="fa fa-list-alt" />
                        All Category</Link>
                    </li>
                  </ul>
                )}
              </li>

              {/* Sub Category Dropdown */}
              <li className="sub-menu">
                <a
                  href="/"
                  onClick={(e) => {
                    e.preventDefault();
                    setIsSubCategoryOpen(isSubCategoryOpen ? false : true);
                  }}
                >
                  <i className="fa fa-list-alt" />
                  <span>Sub Category</span>
                  <span className="dcjq-icon" />
                </a>
                {isSubCategoryOpen && (
                  <ul className="sub">
                    <li>
                      <Link to="/Category">
                        <i className="fa fa-list-alt" />
                        Add Sub Category
                      </Link>
                    </li>
                    <li>
                      <Link to="/AllSubCategory">
                       <i className="fa fa-list-alt" />
                        All Sub Category
                      </Link>
                    </li>
                  </ul>
                )}
              </li>

              <li>
                <Link to="/users">
                <i className="fa fa-user" />
                  <span>Users</span>
                </Link>
              </li>
              <li>
                <Link to="/posts">
                  <i className="fa fa-envelope" />
                  <span>Posts</span>
                </Link>
              </li>
              <li>
                <Link to="/inquiry">
                  <i className="fa fa-question-circle" />
                  <span>Inquiry</span>
                </Link>
              </li>
              <li>
                <Link to="/feedback">
                  <i className="fa fa-comment" />
                  <span>Feedback</span>
                </Link>
              </li>
              <li>
                <Link to="/login" >
                  <i className="fa fa-sign-in" />
                  <span>Login Page</span>
                </Link>
              </li>
            </ul>
          </div>
          {/* sidebar menu end*/}
        </div>
      </aside>
      {/*sidebar end*/}
    </>
  );
}

export default Sidebar;
