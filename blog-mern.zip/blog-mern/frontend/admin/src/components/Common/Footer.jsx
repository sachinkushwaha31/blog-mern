import React from 'react'

function Footer() {
  return (
    <>
  {/* footer */}
  <div className="footer">
    <div className="wthree-copyright">
      <p>
        © 2025 Newsblog. All rights reserved | Design by{" "}
        <a href="http://w3layouts.com">Newblog</a>
      </p>
    </div>
  </div>
  {/* / footer */}
</>
  )
}

export default Footer