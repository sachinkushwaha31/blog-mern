import React from "react";
import { useNavigate } from "react-router-dom";

function Login() {
  const navigate = useNavigate();

  return (
    <>
      <div className="log-w3">
        <div className="w3layouts-main">
          <h2>Sign In Now</h2>
          <form>
            <input
              type="email"
              className="ggg"
              name="Email"
              placeholder="E-MAIL"
              required=""
            />
            <input
              type="password"
              className="ggg"
              name="Password"
              placeholder="PASSWORD"
              required=""
            />
            <span>
              <input type="checkbox" className="me-1" />
              Remember Me
            </span>
            <h6>
              <a href="forgot">Forgot Password?</a>
            </h6>
            <div className="clearfix" />
            <input type="submit" placeholder="Submit" onClick={()=>navigate("/dashboard")} />
          </form>
          {/* <p>
            Don't Have an Account ?
            <a href="registration.html">Create an account</a>
          </p> */}
        </div>
      </div>
    </>
  );
}

export default Login;
