import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function AddSubCategory() {
  const [subCategoryForm, setSubCategoryForm] = useState({
    category: "",
    subcategory: "",
    category_id: ""
  });

  const navigate = useNavigate();

  const getCategoryId = (category) => {
    switch (category) {
      case "technology": return "1";
      case "eduction": return "2";
      case "sports": return "3";
      case "politics": return "4";
      default: return "";
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost/newsblog/subCategory_add.php", subCategoryForm);
      setSubCategoryForm({ category: "", subcategory: "", category_id: "" });
    } catch (err) {
      console.error("Error adding sub category:", err.message);
    }
  };

  return (
    <>
      <section id="main-content">
        <section className="wrapper">
          <div className="form-w3layouts">
            <div className="row">
              <div className="col-lg-12">
                <section className="panel">
                  <header className="panel-heading">Add Sub Category</header>
                  <div className="panel-body">
                    <div className="form">
                      <form
                        className="cmxform form-horizontal"
                        id="commentForm"
                        noValidate="novalidate"
                        onSubmit={handleSubmit}
                      >

                        <div className="form-group">
                          <label htmlFor="category" className="control-label col-lg-3">
                            Category
                          </label>
                          <div className="col-lg-6">
                            <select
                              className="form-select"
                              aria-label="Default select example"
                              value={subCategoryForm.category}
                              onChange={(e) =>
                                setSubCategoryForm({
                                  ...subCategoryForm,
                                  category: e.target.value,
                                  category_id: getCategoryId(e.target.value)
                                })
                              }
                            >
                              <option value="">Select Category</option>
                              <option value="technology">Technology</option>
                              <option value="eduction">Eduction</option>
                              <option value="sports">Sports</option>
                              <option value="politics">Politics</option>
                            </select>
                          </div>
                        </div>

                        <div className="form-group">
                          <label htmlFor="subcategory" className="control-label col-lg-3">
                            Sub Category
                          </label>
                          <div className="col-lg-6">
                            <input
                              className="form-control"
                              id="subcategory"
                              name="subcategory"
                              minLength={2}
                              type="text"
                              required
                              value={subCategoryForm.subcategory}
                              onChange={(e) =>
                                setSubCategoryForm({ ...subCategoryForm, subcategory: e.target.value })
                              }
                            />
                          </div>
                        </div>

                        <div className="form-group">
                          <div className="col-lg-offset-3 col-lg-6">
                            <button className="btn btn-primary button-right" type="submit" onClick={() => navigate("/AllSubCategory")}>
                              Add
                            </button>
                            <button
                              className="btn btn-default me-2"
                              type="button"
                              onClick={() => navigate("/Dashboard")}
                            >
                              Cancel
                            </button>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </section>
              </div>
            </div>
          </div>
        </section>
      </section>
    </>
  );
}

export default AddSubCategory;
