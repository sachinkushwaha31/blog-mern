import React, { useEffect, useState } from 'react'
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function AllUser() {
  const navigate = useNavigate();
  const [users, setUsers] = useState([]);

  function handleGetUsers(){
    const response = axios.get("http://localhost:3000/users").then((res)=>setUsers(res.data))
  }
  useEffect(()=>{
    handleGetUsers();
  },[]);

  return (
    <section id="main-content">
      <section className="wrapper">
        <div className="table-agile-info">
          <div className="panel panel-default">
            <div className="panel-heading">All Users</div>
            <div>
              <table
                className="table"
                ui-jq="footable"
                ui-options='{"paging": {"enabled": true}, "filtering": { "enabled": true }, "sorting": { "enabled": true }}'
              >
                <thead>
                  <tr>
                    <th data-breakpoints="xs">User ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Registration Date</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((user) => (
                    <tr key={user.id} data-expanded="true">
                      <td>{user.id}</td>
                      <td>{user.firstName}</td>
                      <td>{user.lastName}</td>
                      <td>{user.registrationDate}</td>
                      <td>
                        <button onClick={()=>navigate(`/user/${user.id}`,{state : {user : user}})} className="btn btn-primary btn-sm">
                          View
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>
    </section>
  );
}

export default AllUser;
