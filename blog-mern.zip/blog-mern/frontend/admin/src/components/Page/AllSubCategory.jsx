import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from "react-router-dom";

function AllSubCategory() {
  const [subCategory, setSubCategory] = useState([]);
  const navigate = useNavigate();

  // function handleGetSubCategory() {
  //   axios.get("http://localhost/newsblog/subCategory_read.php", subCategory)
  //     .then((res) => setSubCategory(res.data))
  //     .catch((err) => console.log("Error fetching subcategory:", err));
  // }

  const handleGetSubCategory = async () => {
    try {
      const res = await axios.get("http://localhost/newsblog/subCategory_read.php", subCategory);
      setSubCategory(res.data);
    } catch (error) {
      console.error("Error fetching category:", error.message);
    }
  };

    const handleDelete = async (id) => {
      try {
        await axios.post("http://localhost/newsblog/subCategory_delete.php", { delId: id });
        handleGetSubCategory();
      } catch (error) {
        console.error("Error deleting category:", error.message);
      }
    };

  useEffect(() => {
    handleGetSubCategory();
  }, []);

  return (
    <section id="main-content">
      <section className="wrapper">
        <div className="table-agile-info">
          <div className="panel panel-default">
            <div className="panel-heading">All SubCategory<button className="btn btn-primary pull-right" style={{ marginTop: '12px' }} onClick={() => navigate("/AddSubCategory")}>Back</button></div>
            <div>
              <table
                className="table"
                ui-jq="footable"
                ui-options='{"paging": {"enabled": true}, "filtering": { "enabled": true }, "sorting": { "enabled": true }}'
              >
                <thead>
                  <tr>
                    <th data-breakpoints="xs">ID</th>
                    <th>Category</th>
                    <th>Sub Category</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {subCategory.map((subcategory) => (
                    <tr key={subcategory.id}>
                      <td>{subcategory.id}</td>
                      <td>{subcategory.category}</td>
                      <td>{subcategory.subcategory}</td>
                      <td>
                        <button className="btn btn-primary me-2">View</button>
                          <button className="btn btn-danger me-2" onClick={() => handleDelete(subcategory.id)}>Delete</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>
    </section>
  );
}

export default AllSubCategory;
