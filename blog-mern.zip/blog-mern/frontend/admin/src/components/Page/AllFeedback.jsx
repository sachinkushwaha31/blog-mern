import React, { useEffect, useState } from 'react'
import axios from 'axios';

function AllFeedback() {
  const [feedback, setFeedback] = useState([]);

  const handleGetFeedback = async () => {
    try {
      const res = await axios.get("http://localhost/newsblog/feedback_read.php");
      setFeedback(res.data);
    } catch (error) {
      console.error("Error fetching feedback:", error.message);
    }
  };

  const handleDelete = async (id) => {
    try {
      if (window.confirm("Are you sure you want to delete this feedback?")) {
        await axios.post("http://localhost/newsblog/feedback_delete.php", { delId: id });
        handleGetFeedback();
      }
    } catch (error) {
      console.error("Error deleting feedback:", error.message);
    }
  };

  useEffect(() => {
    handleGetFeedback();
  }, []);

  return (
    <>
      <section id="main-content">
        <section className="wrapper">
          <div className="table-agile-info">
            <div className="panel panel-default">
              <div className="panel-heading">All Feedback</div>
              <div>
                <table
                  className="table"
                  ui-jq="footable"
                  ui-options='{"paging": {"enabled": true}, "filtering": { "enabled": true }, "sorting": { "enabled": true }}'
                >
                  <thead>
                    <tr>
                      <th data-breakpoints="xs">ID</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Phone</th>
                      <th>Rating</th>
                      <th>Message</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {feedback.map((fb) => (
                      <tr key={fb.id}>
                        <td>{fb.id}</td>
                        <td>{fb.name}</td>
                        <td>{fb.email}</td>
                        <td>{fb.phone}</td>
                        <td>{fb.rating}</td>
                        <td>{fb.message}</td>
                        <td>
                          {/* You can add a View functionality if needed */}
                          <button className="btn btn-danger me-2" onClick={() => handleDelete(fb.id)}>Delete</button>
                        </td>
                      </tr>
                    ))}
                    {feedback.length === 0 && (
                      <tr>
                        <td colSpan="7" style={{ textAlign: 'center' }}>No feedback found.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </section>
      </section>
    </>
  );
}

export default AllFeedback;
