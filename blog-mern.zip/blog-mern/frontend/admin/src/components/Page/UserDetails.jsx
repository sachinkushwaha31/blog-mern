import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function UserDetailsList() {
  const [users, setUsers] = useState([]);
  const navigate = useNavigate();

  // Fetch users from PHP backend
  const fetchUsers = async () => {
    try {
      const res = await axios.get("http://localhost/newsblog/users_read.php");
      setUsers(res.data); // assumes res.data is an array of users
    } catch (error) {
      console.error("Error fetching users:", error.message);
      alert("Failed to fetch users.");
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  return (
    <section id="main-content">
      <section className="wrapper">
        <div className="table-agile-info">
          <div className="panel panel-default">
            <div className="panel-heading clearfix">
              User List
              <button
                className="btn btn-primary pull-right mt-10"
                onClick={() => navigate(-1)}
              >
                Back
              </button>
            </div>
            <div className="table-responsive">
              <table className="table table-striped b-t b-light">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Password</th>
                    <th>Photo</th>
                    <th style={{ width: "150px" }}>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {users.length > 0 ? (
                    users.map((user) => (
                      <tr key={user.id}>
                        <td>{user.id}</td>
                        <td>{user.firstName}</td>
                        <td>{user.lastName}</td>
                        <td>{user.userName}</td>
                        <td>{user.email}</td>
                        <td>{user.password}</td>
                        <td>
                          {user.photo_path ? (
                            <img
                              src={`http://localhost/newsblog/uploads/${user.photo}`}
                              alt="user"
                              width={60}
                              height={60}
                              style={{ objectFit: "cover", borderRadius: "50%" }}
                            />
                          ) : (
                            "No photo"
                          )}
                        </td>
                        <td>
                          <button
                            className="btn btn-sm btn-info mr-2"
                            onClick={() =>
                              navigate("/users", { state: { user } })
                            }
                          >
                            View
                          </button>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="5">No users found.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>
    </section>
  );
}

export default UserDetailsList;
