import React, { useEffect, useState, useCallback } from "react";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";

function Category() {
  const [category, setCategory] = useState("");
  const { id } = useParams();
  const navigate = useNavigate();
  const isEdit = Boolean(id);

  // Fetch category by ID (Edit mode)
  const fetchCategoryById = useCallback(async () => {
    try {
      const res = await axios.post(
        "http://localhost/newsblog/category_update.php",
        { id },
        {
          headers: { "Content-Type": "application/json" },
        }
      );
      setCategory(res.data.category);
    } catch (err) {
      console.error("Error fetching category:", err.message);
    }
  }, [id]);

  useEffect(() => {
    if (isEdit) {
      fetchCategoryById();
    }
  }, [isEdit, fetchCategoryById]);

  // Handle Add Category
  const handleAddCategory = async () => {
    try {
      await axios.post(
        "http://localhost/newsblog/category_add.php",
        { category },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      navigate("/AllCategory");
    } catch (err) {
      console.error("Add failed:", err.message);
    }
  };

  // Handle Update Category
  const handleUpdateCategory = async () => {
    try {
      await axios.post(
        "http://localhost/newsblog/category_update.php",
        { id, category },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      navigate("/AllCategory");
    } catch (err) {
      console.error("Update failed:", err.message);
    }
  };

  // Main form submission handler
  const handleSubmit = (e) => {
    e.preventDefault();
    isEdit ? handleUpdateCategory() : handleAddCategory();
  };

  return (
    <section id="main-content">
      <section className="wrapper">
        <div className="form-w3layouts">
          <div className="row">
            <div className="col-lg-12">
              <section className="panel">
                <header className="panel-heading">
                  {isEdit ? "Update" : "Add"} Category
                </header>
                <div className="panel-body">
                  <div className="form">
                    <form
                      className="cmxform form-horizontal"
                      onSubmit={handleSubmit}
                      noValidate
                    >
                      <div className="form-group">
                        <label htmlFor="category" className="control-label col-lg-3">
                          Category
                        </label>
                        <div className="col-lg-6">
                          <input
                            className="form-control"
                            id="category"
                            name="category"
                            type="text"
                            minLength={2}
                            required
                            value={category}
                            onChange={(e) => setCategory(e.target.value)}
                          />
                        </div>
                      </div>
                      <div className="form-group">
                        <div className="col-lg-offset-3 col-lg-6">
                          <button className="btn btn-primary me-2" type="submit">
                            {isEdit ? "Update" : "Add"}
                          </button>
                          <button
                            className="btn btn-default"
                            type="button"
                            onClick={() => navigate("/AllCategory")}
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </section>
            </div>
          </div>
        </div>
      </section>
    </section>
  );
}

export default Category;
