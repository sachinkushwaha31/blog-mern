import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function AllCategory() {
  const [categories, setCategories] = useState([]);
  const navigate = useNavigate();

  const handleGetCategory = async () => {
    try {
      const res = await axios.get("http://localhost/newsblog/category_read.php");
      setCategories(res.data);
    } catch (error) {
      console.error("Error fetching category:", error.message);
    }
  };

  const handleDelete = async (id) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this category?");
    if (!confirmDelete) return;

    try {
      await axios.post("http://localhost/newsblog/category_delete.php", { delId: id });
      handleGetCategory();
    } catch (error) {
      console.error("Error deleting category:", error.message);
    }
  };

  useEffect(() => {
    handleGetCategory();
  }, []);

  return (
    <section id="main-content">
      <section className="wrapper">
        <div className="table-agile-info">
          <div className="panel panel-default">
            <div className="panel-heading d-flex justify-content-between align-items-center">
              <h4>All Category</h4>
              <button className="btn btn-primary" onClick={() => navigate("/addcategory")}>
                Add Category
              </button>
            </div>

            <div className="table-responsive">
              <table className="table table-bordered table-hover">
                <thead className="thead-dark">
                  <tr>
                    <th>ID</th>
                    <th>Category</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {categories.length > 0 ? (
                    categories.map((cat) => (
                      <tr key={cat.id}>
                        <td>{cat.id}</td>
                        <td>{cat.category}</td>
                        <td>
                          <button
                            className="btn btn-success btn-sm me-2"
                            onClick={() => navigate(`/addcategory/${cat.id}`)}
                          >
                            Update
                          </button>
                          <button
                            className="btn btn-danger btn-sm"
                            onClick={() => handleDelete(cat.id)}
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="3" className="text-center">
                        No categories found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>
    </section>
  );
}

export default AllCategory;
