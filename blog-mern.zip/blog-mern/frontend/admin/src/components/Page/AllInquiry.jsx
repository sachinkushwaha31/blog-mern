import React, { useEffect, useState } from "react";
import axios from "axios";

function AllInquiry() {
  const [inquiries, setInquiries] = useState([]);

  const handleGetInquiries = async () => {
    try {
      const res = await axios.get("http://localhost/newsblog/inquiry_read.php");
      setInquiries(res.data);
    } catch (error) {
      console.error("Error fetching inquiries:", error.message);
    }
  };

  useEffect(() => {
    handleGetInquiries();
  }, []);

  const handleDelete = async (id) => {
    try {
      await axios.post("http://localhost/newsblog/inquiry_delete.php", { delId: id });
      handleGetInquiries();
    } catch (error) {
      console.error("Error deleting inquiry:", error.message);
    }
  };

  return (
    <>
      <section id="main-content">
        <section className="wrapper">
          <div className="table-agile-info">
            <div className="panel panel-default">
              <div className="panel-heading">All Inquiry</div>
              <div>
                <table
                  className="table"
                  ui-jq="footable"
                  ui-options='{"paging": {"enabled": true}, "filtering": { "enabled": true }, "sorting": { "enabled": true }}'
                >
                  <thead>
                    <tr>
                      <th data-breakpoints="xs">Inquiry ID</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Subject</th>
                      <th>Message</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {inquiries.map((inquiry) => (
                      <tr key={inquiry.id}>
                        <td>{inquiry.id}</td>
                        <td>{inquiry.name}</td>
                        <td>{inquiry.email}</td>
                        <td>{inquiry.subject}</td>
                        <td>{inquiry.message}</td>
                        <td>
                          <button className="btn btn-primary btn-sm me-2">
                            View
                          </button>
                          <button
                            className="btn btn-danger btn-sm"
                            onClick={() => handleDelete(inquiry.id)}
                          >
                            Delete
                          </button>                          
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </section>
      </section>
    </>
  );
}

export default AllInquiry;
