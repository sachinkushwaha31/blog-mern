import React, { useEffect, useState } from 'react'
import axios from 'axios';

function AllPost() {
  const [posts, setPosts] = useState([]);

  function handleGetPosts(){
    const response = axios.get("http://localhost:3000/posts").then((res)=>setPosts(res.data))
  }
  useEffect(()=>{
    handleGetPosts();
  },[]);

  return (
    <section id="main-content">
      <section className="wrapper">
        <div className="table-agile-info">
          <div className="panel panel-default">
            <div className="panel-heading">All Post</div>
            <div className="table-responsive">
              <table
                className="table footable"
                ui-jq="footable"
                ui-options='{"paging": {"enabled": true}, "filtering": { "enabled": true }, "sorting": { "enabled": true }}'
              >
                <thead>
                  <tr>
                    <th data-breakpoints="xs">ID</th>
                    <th>Post Title</th>
                    <th>User</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {posts.map((post) => (
                    <tr key={post.id} data-expanded="true">
                      <td>{post.id}</td>
                      <td>{post.title}</td>
                      <td>{post.userName}</td>
                      <td>
                        <button className="btn btn-primary btn-sm">View</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>
    </section>
  );
}

export default AllPost;
