import React from "react";
import { Link } from "react-router-dom";

function Dashboard() {
  return (
    <section id="main-content">
      <section className="wrapper">
        {/* //market*/}
        <div className="market-updates">
          <div className="col-md-3 market-update-gd">
            <div className="market-update-block clr-block-2">
              <div className="col-md-4 market-update-right">
                <i className="fa fa-users" />
              </div>
              <div className="col-md-8 market-update-left">
                <Link to="/users">
                    <h4>Users</h4>
                  </Link>
                <h3>1250</h3>
                <p>Other hand, we denounce</p>
              </div>
              <div className="clearfix"> </div>
            </div>
          </div>
          <div className="col-md-3 market-update-gd">
            <div className="market-update-block clr-block-1">
              <div className="col-md-4 market-update-right">
                <i className="fa fa-envelope" />
              </div>
              <div className="col-md-8 market-update-left">
                <Link to="/posts">
                    <h4>Posts</h4>
                  </Link>
                <h3>1500</h3>
                <p>Other hand, we denounce</p>
              </div>
              <div className="clearfix"> </div>
            </div>
          </div>
          <div className="col-md-3 market-update-gd">
            <div className="market-update-block clr-block-3">
              <div className="col-md-4 market-update-right">
                <i className="fa fa-question-circle" />
              </div>
              <div className="col-md-8 market-update-left">
                <Link to="/inquiry">
                  <h4>Inquiry</h4>
                </Link>
                <h3>1000</h3>
                <p>Other hand, we denounce</p>
              </div>
              <div className="clearfix"> </div>
            </div>
          </div>
          <div className="col-md-3 market-update-gd">
            <div className="market-update-block clr-block-4">
              <div className="col-md-4 market-update-right">
                <i className="fa fa-comment" />
              </div>
              <div className="col-md-8 market-update-left">
                <Link to="/feedback">
                  <h4>Feedback</h4>
                </Link>
                <h3>1,500</h3>
                <p>Other hand, we denounce</p>
              </div>
              <div className="clearfix"> </div>
            </div>
          </div>
          <div className="clearfix"> </div>
        </div>
        {/* //market*/}
      </section>
    </section>
  );
}

export default Dashboard;
